package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class case1 {
    static WebDriver driver;
;
//Driverın ayağa kaldırılma ve siteye giriş methodu yazıldı
    static void setup(){
        System.setProperty("webdriver.chrome.driver","C:\\webdrivers\\chromedriver.exe");
        driver=new ChromeDriver();
        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
        driver.get(" https://www.imdb.com");
    }
//menu bardan film bulma fonksiyonu
    static void menu(){
        setup();
        WebElement menu=driver.findElement(By.className("ipc-button__text"));
        menu.click();
        WebElement oscar=driver.findElement(By.xpath("//*[contains(@href,\"oscars/?ref_=nv_ev_acd\")]"));
        oscar.click();
        WebElement event=driver.findElement(By.xpath("//*[contains(@href,\"event/ev0000003/1929\")]"));
        event.click();
        WebElement movie=driver.findElement(By.xpath("(//*[contains(@href,\"title/tt0018037/?ref_=ev_nom\")])[5]"));
        movie.click();

    }
//icona tıklayıp ana sayfaya dönme fonksiyonu
    static void backhomepage() {

        WebElement back=driver.findElement(By.xpath("//(//*[contains(@href,\"ref_=nv_home\")])[2]"));
        back.click();
    }
    //searchbardan arama işlemi
    static void searchbar() {

        WebElement search_area2= driver.findElement(By.xpath("//input[@name='q\']"));
        search_area2.click();
        search_area2.sendKeys("The Jazz Singer");
        search_area2.submit();
        WebElement result=driver.findElement(By.xpath("(//*[contains(@href,\"title/tt0080948\")])[1]"));
        result.click();

        WebElement allphoto=driver.findElement(By.xpath("(//*[contains(@href,\"title/tt0080948/mediaindex\")])[1]"));
        allphoto.click();

    }
// iki taraftan elde edilen bilgilerin karşılaştırılması fonksiyonu
static void sameornot(){
    menu();

    String directors1= driver.findElement(By.xpath("(//*[contains(@href,\"name/nm0189076/?ref_=tt_ov_dr\")])[1]")).getText();
    String writers1= driver.findElement(By.xpath("(//*[contains(@href,\"name/nm0710723/?ref_=tt_ov_wr\")])[1]")).getText();
    String stars1= driver.findElement(By.xpath("(//*[contains(@href,\"name/nm0427231/?ref_=tt_ov_st\")])[1]")).getText();

    backhomepage();
    searchbar();

    String directors2= driver.findElement(By.xpath("//*[contains(@href,\"name/nm0281507?ref_=tt_cl_dr_1\")]")).getText();
    String writers2= driver.findElement(By.xpath("//*[contains(@href,\"name/nm0710723?ref_=tt_cl_wr_1\")]")).getText();
    String stars2= driver.findElement(By.xpath("(//*[contains(@href,\"nm0000059/?ref_=tt_ov_st\")])[1]")).getText();

    if(directors1==directors2&&writers1==writers2&&stars1==stars2){
        System.out.println("Same movie");
    }
    else {
        System.out.println("Different movie");
    }
}


    public static void main(String[] args) {
      sameornot();


    }
}
